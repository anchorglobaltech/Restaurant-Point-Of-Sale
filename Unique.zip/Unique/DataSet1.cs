﻿namespace UniqueRestaurant {
    
    
    public partial class DataSet1 {
    }
}
